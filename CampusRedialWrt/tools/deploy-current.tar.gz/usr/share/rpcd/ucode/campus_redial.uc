'use strict';

import { popen, readfile } from 'fs';

const run_dir = '/var/run/campus-redial';
const status_file = `${run_dir}/status.json`;
const log_file = '/var/log/campus-redial.log';

function status() {
	let value = readfile(status_file);
	if (!value)
		return { running: false, state: 'unavailable', normal: 'unknown', mbps200: 'unknown', last_error: '后台服务尚未启动' };
	try {
		let result = json(value);
		let stats = readfile('/etc/campus-redial/stats.json');
		let last = readfile('/etc/campus-redial/last-run.json');
		if (stats) result.stats = json(stats);
		if (last) result.last_run = json(last);
		return result;
	} catch (e) {
		return { running: false, state: 'error', last_error: '状态文件损坏' };
	}
}

function command(name) {
	switch (name) {
	case 'start': case 'stop': case 'test': case 'redial_once': case 'clear_stats': break;
	default: return { error: 'Invalid command' };
	}
	let rc = system(`/usr/sbin/campus-redialctl ${name}`);
	return rc === 0 ? { result: true } : { error: '后台服务未运行' };
}

function logs(request) {
	let lines = +(request.args?.lines ?? 80);
	if (lines < 1 || lines > 200) return { error: 'lines must be between 1 and 200' };
	let fd = popen(`tail -n ${lines} ${log_file} 2>/dev/null`);
	if (!fd) return { logs: '' };
	let text = fd.read('all'); fd.close();
	return { logs: text ?? '' };
}

const methods = {
	status: { call: status },
	start: { call: () => command('start') },
	stop: { call: () => command('stop') },
	test: { call: () => command('test') },
	redial_once: { call: () => command('redial_once') },
	clear_stats: { call: () => command('clear_stats') },
	logs: { args: { lines: 0 }, call: logs }
};

return { campus_redial: methods };
