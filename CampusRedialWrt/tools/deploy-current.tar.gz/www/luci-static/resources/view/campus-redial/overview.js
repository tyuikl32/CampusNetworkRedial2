'use strict';
'require view';
'require form';
'require rpc';
'require ui';

// LuCI 21.02 has no dom/poll modules: L.dom and L.Poll live in luci.js.
function appendOne(node, child) {
	if (child instanceof Node)
		node.appendChild(child);
	else if (child !== null && child !== undefined && child !== '')
		node.appendChild(document.createTextNode(String(child)));
}

function setContent(node, children) {
	while (node.firstChild)
		node.removeChild(node.firstChild);
	if (Array.isArray(children))
		children.forEach(function (child) { appendOne(node, child); });
	else
		appendOne(node, children);
}

const callStatus = rpc.declare({ object: 'campus_redial', method: 'status', expect: {} });
const callLogs = rpc.declare({ object: 'campus_redial', method: 'logs', params: [ 'lines' ], expect: {} });
const callStart = rpc.declare({ object: 'campus_redial', method: 'start', expect: {} });
const callStop = rpc.declare({ object: 'campus_redial', method: 'stop', expect: {} });
const callTest = rpc.declare({ object: 'campus_redial', method: 'test', expect: {} });
const callRedial = rpc.declare({ object: 'campus_redial', method: 'redial_once', expect: {} });
const callClear = rpc.declare({ object: 'campus_redial', method: 'clear_stats', expect: {} });

const stateNames = {
	idle: _('空闲'), unavailable: _('后台未启动'), starting: _('正在启动'),
	waiting_network: _('等待网络'), dialing: _('正在拨号'), testing: _('正在检测'),
	redialing: _('正在重拨'), success: _('成功'), failed: _('失败'),
	stopped: _('已停止'), error: _('错误'), up: _('在线'), down: _('离线'),
	busy: _('流量繁忙，检测已挂起')
};

const resultNames = {
	disabled: _('未启用'), waiting: _('等待'), testing: _('检测中'),
	success: _('成功'), failure: _('失败'), failed: _('失败'), unknown: _('未知')
};

const dialNames = {
	 down: _('未连接'), dialing: _('拨号中'), up: _('已连接')
};

const detectionNames = {
	 waiting: _('待检测'), testing: _('检测中'), queued: _('等待检测'),
	 passed: _('检测通过'), failed: _('检测未通过')
};

function text(value, fallback) {
	return value === null || value === undefined || value === '' ? (fallback || '-') : String(value);
}

/* DynamicList hands the empty "add a new item" input to validate() as '',
 * and may pass the whole list joined by whitespace, so accept empties and
 * check each token instead of the raw string. */
function httpListValidator(sid, value) {
	if (value === null || value === undefined || value === '')
		return true;
	const items = String(value).split(/\s+/).filter(v => v !== '');
	if (items.length === 0)
		return true;
	return items.every(item => /^https?:\/\//.test(item)) || _('必须是 HTTP 或 HTTPS 地址');
}

function statusClass(value) {
	if (value === 'success') return 'label notice-success';
	if (value === 'failed' || value === 'failure' || value === 'error') return 'label notice-error';
	if (value === 'testing' || value === 'dialing' || value === 'redialing' || value === 'starting' || value === 'busy') return 'label notice-warning';
	return 'label';
}

function badge(value, names) {
	return E('span', { 'class': statusClass(value) }, text(names[value], value));
}

function metric(label, value) {
	return E('div', { 'style': 'min-width:10rem;padding:.45rem 0' }, [
		E('div', { 'style': 'color:var(--text-color-medium,#666);font-size:.85em' }, label),
		E('strong', { 'style': 'font-size:1.15em' }, text(value, '0'))
	]);
}

return view.extend({
	load() {
		return Promise.all([ callStatus(), callLogs(80) ]);
	},

	updateStatus(status, logs) {
		status = status || {};
		logs = logs || {};
		const stats = status.stats || {};
		const last = status.last_run || {};
		setContent(this.overallNode, badge(status.state || 'unavailable', stateNames));
		setContent(this.normalNode, badge(status.normal || 'unknown', resultNames));
		setContent(this.speedNode, [ badge(status.mbps200 || 'unknown', resultNames), ' ', E('span', {}, text(status.speed_mbps, '0') + ' Mbps') ]);
		setContent(this.poolCountNode, [
			_('已连接 %s / %s；检测通过 %s / %s').format(
				text(status.connected_count, '0'), text(status.pool_size, '1'),
				text(status.verified_count, '0'), text(status.pool_size, '1')),
			E('div', { 'style': 'color:var(--text-color-medium,#666);font-size:.9em' },
				_('已连接但尚未通过检测的会话仍可参与分流'))
		]);
		setContent(this.errorNode, text(status.last_error, _('无')));
		setContent(this.updatedNode, text(status.updated_at));
		setContent(this.currentStatsNode, [
			metric(_('拨号尝试'), status.dial_attempts),
			metric(_('失败后重拨'), status.redial_count),
			metric(_('本次成功'), status.run_success),
			metric(_('本次失败'), status.run_failure)
		]);
		setContent(this.lastStatsNode, [
			metric(_('结果'), resultNames[last.result] || last.result),
			metric(_('拨号尝试'), last.dial_attempts),
			metric(_('重拨次数'), last.redial_count),
			metric(_('测速'), text(last.speed_mbps, '0') + ' Mbps')
		]);
		setContent(this.totalStatsNode, [
			metric(_('累计拨号'), stats.dial_attempts),
			metric(_('累计重拨'), stats.redial_count),
			metric(_('成功任务'), stats.success_count),
			metric(_('失败任务'), stats.failure_count),
			metric(_('普通模式通过'), stats.normal_pass_count),
			metric(_('200 Mbps 通过'), stats.mbps200_pass_count)
		]);
		setContent(this.logNode, text(logs.logs, _('暂无日志')));
		// Per-session table (connection pool): one row per session with its
		// own state, speed and error badge.
		const sessions = Array.isArray(status.sessions) ? status.sessions : [];
		const rows = [];
		(sessions.length ? sessions : []).forEach(s => {
			const accountName = text(s.account_label || s.account, _('未分配'));
			const accountId = s.account ? String(s.account) : '';
			rows.push(E('tr', { 'class': 'tr' }, [
				E('td', { 'class': 'td left' }, text(s.name)),
				E('td', { 'class': 'td left' }, accountId && accountId !== accountName ? accountName + ' (' + accountId + ')' : accountName),
				E('td', { 'class': 'td left' }, badge(s.state, stateNames)),
				E('td', { 'class': 'td left' }, badge(s.dial_state, dialNames)),
				E('td', { 'class': 'td left' }, badge(s.detection_state, detectionNames)),
				E('td', { 'class': 'td left' }, badge(s.normal, resultNames)),
				E('td', { 'class': 'td left' }, badge(s.mbps200, resultNames)),
				E('td', { 'class': 'td left' }, text(s.speed_mbps, '0') + ' Mbps'),
				E('td', { 'class': 'td left' }, [
					E('div', {}, _('下行：%s Mbps').format(text(s.rx_mbps, '0'))),
					E('div', {}, _('上行：%s Mbps').format(text(s.tx_mbps, '0'))),
					E('div', {}, _('连接数：%s').format(text(s.connections, '0')))
				]),
				E('td', { 'class': 'td left' }, [
					E('div', {}, _('收：%s MB').format((Number(s.rx_bytes || 0) / 1048576).toFixed(2))),
					E('div', {}, _('发：%s MB').format((Number(s.tx_bytes || 0) / 1048576).toFixed(2)))
				]),
				E('td', { 'class': 'td left' }, [
					E('div', {}, _('拨号/重拨：%s / %s').format(text(s.dial_attempts, '0'), text(s.redial_count, '0'))),
					E('div', {}, _('成功/失败：%s / %s').format(text(s.success_count, '0'), text(s.failure_count, '0'))),
					E('div', {}, _('普通/200M 通过：%s / %s').format(text(s.normal_pass_count, '0'), text(s.mbps200_pass_count, '0')))
				]),
				E('td', { 'class': 'td left' }, text(s.error, ''))
			]));
		});
		setContent(this.sessionBody, rows);
		if (!status.sessions || !status.sessions.length)
			setContent(this.sessionEmptyNode, E('em', {}, _('后台尚未建立会话')));
		else
			setContent(this.sessionEmptyNode, E('span'));
		this.startButton.disabled = !!status.running;
		this.testButton.disabled = !!status.running;
		this.redialButton.disabled = !!status.running;
		this.stopButton.disabled = !status.running;
	},

	refresh() {
		return Promise.all([ callStatus(), callLogs(80) ])
			.then(data => this.updateStatus(data[0], data[1]))
			.catch(err => setContent(this.errorNode, _('无法连接后台：%s').format(err.message)));
	},

	runAction(call, successText) {
		return call().then(() => {
			ui.addNotification(null, E('p', successText));
			return new Promise(resolve => window.setTimeout(resolve, 350)).then(() => this.refresh());
		}).catch(err => ui.addNotification(null, E('p', _('操作失败：%s').format(err.message))));
	},

	render(data) {
		this.overallNode = E('span');
		this.normalNode = E('span');
		this.speedNode = E('span');
		this.poolCountNode = E('span');
		this.errorNode = E('span');
		this.updatedNode = E('span');
		this.currentStatsNode = E('div', { 'style': 'display:flex;gap:2rem;flex-wrap:wrap' });
		this.lastStatsNode = E('div', { 'style': 'display:flex;gap:2rem;flex-wrap:wrap' });
		this.totalStatsNode = E('div', { 'style': 'display:flex;gap:2rem;flex-wrap:wrap' });
		this.logNode = E('pre', { 'style': 'max-height:18rem;overflow:auto;white-space:pre-wrap' });
		this.sessionBody = E('tbody');
		this.sessionEmptyNode = E('span');

		this.startButton = E('button', { 'class': 'cbi-button cbi-button-action', 'click': ui.createHandlerFn(this, () => this.runAction(callStart, _('自动重拨已启动'))) }, _('启动'));
		this.stopButton = E('button', { 'class': 'cbi-button cbi-button-negative', 'click': ui.createHandlerFn(this, () => this.runAction(callStop, _('已请求停止'))) }, _('停止'));
		this.testButton = E('button', { 'class': 'cbi-button', 'click': ui.createHandlerFn(this, () => this.runAction(callTest, _('当前出口检测已启动'))) }, _('测试当前出口'));
		this.redialButton = E('button', { 'class': 'cbi-button cbi-button-positive', 'click': ui.createHandlerFn(this, () => this.runAction(callRedial, _('单次重拨已启动'))) }, _('立即重拨一次'));
		const clearButton = E('button', { 'class': 'cbi-button', 'click': ui.createHandlerFn(this, () => this.runAction(callClear, _('累计统计已清空'))) }, _('清空统计'));

		const statusPanel = E('div', {}, [
			E('h2', _('运行状态')),
			E('table', { 'class': 'table' }, [
				E('tr', { 'class': 'tr' }, [ E('td', { 'class': 'td left', 'width': '25%' }, _('进程')), E('td', { 'class': 'td left' }, this.overallNode) ]),
				E('tr', { 'class': 'tr' }, [ E('td', { 'class': 'td left' }, _('普通模式')), E('td', { 'class': 'td left' }, this.normalNode) ]),
				E('tr', { 'class': 'tr' }, [ E('td', { 'class': 'td left' }, _('200 Mbps 模式')), E('td', { 'class': 'td left' }, this.speedNode) ]),
			E('tr', { 'class': 'tr' }, [ E('td', { 'class': 'td left' }, _('连接池状态（连接/检测）')), E('td', { 'class': 'td left' }, this.poolCountNode) ]),
				E('tr', { 'class': 'tr' }, [ E('td', { 'class': 'td left' }, _('最后错误')), E('td', { 'class': 'td left' }, this.errorNode) ]),
				E('tr', { 'class': 'tr' }, [ E('td', { 'class': 'td left' }, _('更新时间')), E('td', { 'class': 'td left' }, this.updatedNode) ])
			]),
			E('div', { 'class': 'cbi-page-actions', 'style': 'display:flex;gap:.5rem;flex-wrap:wrap' }, [ this.startButton, this.stopButton, this.testButton, this.redialButton, clearButton ]),
			E('h3', _('连接池会话')),
			E('p', {}, this.sessionEmptyNode),
			E('table', { 'class': 'table' }, [
				E('thead', {}, [ E('tr', { 'class': 'tr table-titles' }, [
					E('th', { 'class': 'th left' }, _('会话')),
					E('th', { 'class': 'th left' }, _('认证账号')),
					E('th', { 'class': 'th left' }, _('状态')),
					E('th', { 'class': 'th left' }, _('拨号连接')),
					E('th', { 'class': 'th left' }, _('检测状态')),
					E('th', { 'class': 'th left' }, _('普通模式')),
					E('th', { 'class': 'th left' }, _('200 Mbps')),
					E('th', { 'class': 'th left' }, _('测速')),
					E('th', { 'class': 'th left' }, _('实时流量/连接')),
					E('th', { 'class': 'th left' }, _('累计流量')),
					E('th', { 'class': 'th left' }, _('会话统计')),
					E('th', { 'class': 'th left' }, _('错误'))
				]) ]),
				this.sessionBody
			]),
			E('h3', _('本次运行')), this.currentStatsNode,
			E('h3', _('最近一次任务')), this.lastStatsNode,
			E('h3', _('累计统计')), this.totalStatsNode
		]);

		let map = new form.Map('campus-redial', _('配置'));
		let section = map.section(form.NamedSection, 'main', 'campus_redial');
		section.anonymous = true;
		let option = section.option(form.Flag, 'enabled', _('开机自动运行'));
		option.rmempty = false;
		option = section.option(form.Value, 'wan_interface', _('PPPoE 逻辑接口'));
		option.default = 'wan'; option.rmempty = false; option.datatype = 'uciname';
		option = section.option(form.Value, 'wan_device', _('PPPoE 下层设备'));
		option.placeholder = _('留空时读取 network.wan.device');
		option = section.option(form.Value, 'pppoe_username', _('校园网账号'));
		option.rmempty = false;
		option = section.option(form.Value, 'pppoe_password', _('校园网密码'));
		option.password = true; option.rmempty = false;
		option = section.option(form.Value, 'pool_size', _('旧版单账号会话数（多账号时忽略）'));
		option.default = '1'; option.datatype = 'range(1,24)';
		option = section.option(form.Flag, 'pool_keepalive', _('持续维护连接池'));
		option.default = '1'; option.rmempty = false;
		option = section.option(form.Value, 'auth_interval_seconds', _('认证最小间隔（秒，多拨推荐 60）'));
		option.default = '60'; option.datatype = 'range(1,60)';
		option = section.option(form.Value, 'busy_threshold_kbytes', _('大流量挂起阈值（KB/s，0=禁用）'));
		option.default = '0'; option.datatype = 'range(0,100000000)';
		option = section.option(form.Flag, 'normal_enabled', _('普通模式'));
		option.rmempty = false; option.default = '1';
		option = section.option(form.Flag, 'mbps200_enabled', _('200 Mbps 模式'));
		option.rmempty = false; option.default = '1';
			option = section.option(form.Value, 'probe_uri', _('普通模式探针'));
			option.rmempty = false;
			option.validate = httpListValidator;
			option.placeholder = _('多个地址用空格分隔');
		option = section.option(form.Value, 'timeout_seconds', _('探测超时（秒）'));
		option.default = '4'; option.datatype = 'range(1,60)';
		option = section.option(form.Value, 'probe_count', _('每个探针每轮次数'));
		option.default = '3'; option.datatype = 'range(1,10)';
		option = section.option(form.Value, 'confirm_interval_seconds', _('第一轮确认间隔（秒）'));
		option.default = '12'; option.datatype = 'range(0,300)';
		option = section.option(form.Value, 'third_interval_seconds', _('第三轮确认间隔（秒）'));
		option.default = '30'; option.datatype = 'range(0,600)';
		option = section.option(form.Value, 'bandwidth_test_uri', _('测速地址'));
		option.rmempty = false; option.validate = httpListValidator;
		option = section.option(form.Value, 'bandwidth_test_seconds', _('测速时长（秒）'));
		option.default = '5'; option.datatype = 'range(1,30)';
		option = section.option(form.Value, 'bandwidth_threshold_mbps', _('通过阈值（Mbps）'));
		option.default = '150'; option.datatype = 'ufloat';
		option = section.option(form.Value, 'settle_seconds', _('拨号稳定等待（秒）'));
		option.default = '10'; option.datatype = 'range(0,300)';
		option = section.option(form.Value, 'pause_seconds', _('失败暂停（秒）'));
		option.default = '2'; option.datatype = 'range(1,600)';
		option = section.option(form.Value, 'max_attempts', _('最大拨号次数'));
		option.default = '99'; option.datatype = 'range(1,99)';

		let accounts = map.section(form.TableSection, 'account', _('多账号连接池'));
		accounts.addremove = true;
		accounts.anonymous = false;
		accounts.sortable = true;
		accounts.nodescriptions = true;
		option = accounts.option(form.Flag, 'enabled', _('启用'));
		option.default = '1'; option.rmempty = false;
		option = accounts.option(form.Value, 'label', _('显示名称'));
		option.placeholder = _('例如：主账号');
		option.depends('enabled', '1');
		option = accounts.option(form.Value, 'username', _('PPPoE 账号'));
		option.depends('enabled', '1'); option.rmempty = false;
		option = accounts.option(form.Value, 'password', _('PPPoE 密码'));
		option.password = true; option.depends('enabled', '1'); option.rmempty = false;
		option = accounts.option(form.Value, 'max_connections', _('最大连接数'));
		option.default = '1'; option.datatype = 'range(1,24)'; option.depends('enabled', '1');

		this.updateStatus(data[0], data[1]);
		L.Poll.add(L.bind(this.refresh, this), 2);
		return map.render().then(formNode => E('div', {}, [
			E('h1', _('校园网自动重拨')),
			statusPanel,
			formNode,
			E('h2', _('最近日志')),
			this.logNode
		]));
	}
});
